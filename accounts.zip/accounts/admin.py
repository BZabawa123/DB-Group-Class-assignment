# admin.py (Final Edit)
from django.contrib import admin
from .models import RSOs, StudentsRSOs

admin.site.register(RSOs)
admin.site.register(StudentsRSOs)
